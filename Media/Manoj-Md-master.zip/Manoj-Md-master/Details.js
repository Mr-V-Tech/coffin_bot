/*
Manoj Md Whatsapp Bot

Telegram: https://t.me/RavinduManoj
Facebook: https://www.facebook.com/ravindu.manoj.79
Youtube: https://youtube.com/c/TechToFuture

Coded By Ravindu Manoj
*/
module.export = {
	name: 'Manoj Multi-device Whatsapp Bot',
	version: require('./pre-package.json').version,
	branch: 'master',
	author: require('./pre-package.json').author
}