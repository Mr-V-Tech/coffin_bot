# Manoj Md Whatsapp Bot                      
#
# Telegram: https://t.me/RavinduManoj
# Facebook: https://www.facebook.com/ravindu.manoj.79
# Licensed under the  GPL-3.0 License;
#
# Coded By Ravindu Manoj
. /root/manoj-multi-device-whatsapp-pre-data.sh

printf "\033c"
# Main Display
echo "${echo_Main_wa_Display}"
# Show Logs
echo "
# Manoj Multi-device Whatsapp Bot
#
#   - Not yet published
#
"